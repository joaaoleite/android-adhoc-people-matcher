
```
nano etc/platform/X/backends.conf
```

```
{
    "backends" : [
        {
            "id" : "avd",
            "connector" : "avd",
            "config" : {
                "sdk" : "/Users/nsantos/Library/Android/sdk",
                "vmi" : "Nexus_5_API_21_x86"                                                                    
            }                                
        }
    ]
}
```


```
nano env/platform/{linux,mac,windows}/env_setup.sh
```

```
...
Working Directory = /Users/<..USER..>/Developer/cmu-project/Termite-Cli
...
```
