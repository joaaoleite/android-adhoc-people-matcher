#!/usr/bin/python2
import sys 
import importlib

importlib.import_module(str(sys.argv[1]))
