#!/usr/bin/env bash

#
# Absolute path to the Termite CLI tool
#
export TERMITE_CLI_PATH=/Users/joaoleite/Developer/cmu-project/Termite-Cli

#
# Target platform; one of: mac, linux, or windows
#
export TERMITE_PLATFORM=mac
